package com.hsbc.insurance.exceptions;

public class FileCreationException extends Exception{

	public FileCreationException(String message)
	{
		super(message);
	}
}
