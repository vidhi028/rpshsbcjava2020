package com.hsbc.insurance.exceptions;

public class VehicleCreationException extends Exception{

	public VehicleCreationException(String message)
	{
		super(message);
	}
}
