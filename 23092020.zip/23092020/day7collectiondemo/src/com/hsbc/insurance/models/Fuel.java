package com.hsbc.insurance.models;

public enum Fuel {
 PETROL,DIESEL,NATURALGAS
}
