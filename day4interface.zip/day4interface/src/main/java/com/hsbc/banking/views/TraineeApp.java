package com.hsbc.banking.views;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Random;

import com.hsbc.banking.bl.SortTraineeByDOB;
import com.hsbc.banking.bl.SortTraineeByName;
import com.hsbc.banking.models.Trainee;

public class TraineeApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Create Array for 5 trainees
        Trainee[] trainees=new Trainee[5];
        
        for(int i=0;i<trainees.length;i++)
        {
        	
        	trainees[i]=new Trainee("user"+new Random().nextInt(20),
        			LocalDate.of(1980+new Random().nextInt(20)+1, 
        					new Random().nextInt(11)+1, new Random().nextInt(26)+1));        	
        }
        
        System.out.println("Before Sorting.....");
        for(Trainee trainee:trainees)
           	System.out.println(trainee);        
        //Sort trainee object by name       
        Arrays.sort(trainees, new SortTraineeByName());
        System.out.println("After Sorting By Name.....");
        for(Trainee trainee:trainees)
           	System.out.println(trainee);
        
        Arrays.sort(trainees, new SortTraineeByDOB());
        System.out.println("After Sorting By DOB.....");
        for(Trainee trainee:trainees)
           	System.out.println(trainee);
        
		
	}

}
