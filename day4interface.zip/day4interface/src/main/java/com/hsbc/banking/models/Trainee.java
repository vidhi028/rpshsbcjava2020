package com.hsbc.banking.models;

import java.time.LocalDate;

//sort the trainees by trainee name or dob
public class Trainee {
//implements Comparable<Trainee> {

	private String name;
	private LocalDate dob;
	public Trainee(String name, LocalDate dob) {
		super();
		this.name = name;
		this.dob = dob;
	}
	
	
	
	public String getName() {
		return name;
	}



	public LocalDate getDob() {
		return dob;
	}



	@Override
	public String toString() {
		return "Trainee [name=" + name + ", dob=" + dob + "]";
	}
	/*
	 * @Override public int compareTo(Trainee trainee) { // TODO Auto-generated
	 * method stub return this.dob.compareTo(trainee.dob); }
	 */
		
	
}
