package com.hsbc.banking.bl;

import java.util.Comparator;

import com.hsbc.banking.models.Trainee;

public class SortTraineeByDOB implements Comparator<Trainee>{

	@Override
	public int compare(Trainee o1, Trainee o2) {
		// TODO Auto-generated method stub
		return o1.getDob().compareTo(o2.getDob());
	}

}
