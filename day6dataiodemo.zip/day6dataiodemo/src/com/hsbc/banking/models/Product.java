package com.hsbc.banking.models;

import java.time.LocalDate;

//Read Id,name,cost,dop and status
public class Product {

	private long productId;
	private String name;
	private int cost;
	private LocalDate dop;
	private boolean status;
	public long getProductId() {
		return productId;
	}
	public void setProductId(long productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public LocalDate getDop() {
		return dop;
	}
	public void setDop(LocalDate dop) {
		this.dop = dop;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", name=" + name + ", cost=" + cost + ", dop=" + dop + ", status="
				+ status + "]";
	}
	
}
