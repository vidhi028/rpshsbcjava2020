package com.hsbc.banking.dao;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.hsbc.banking.exceptions.ProductCostException;
import com.hsbc.banking.models.Product;

//add single product and retrieve
public interface ProductDao {
	
	boolean addProduct(Product product)throws IOException,
	FileNotFoundException,ProductCostException;
	Product getProduct() throws IOException;

}
