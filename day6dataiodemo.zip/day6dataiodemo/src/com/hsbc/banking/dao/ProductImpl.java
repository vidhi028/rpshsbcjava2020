package com.hsbc.banking.dao;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.hsbc.banking.exceptions.ProductCostException;
import com.hsbc.banking.models.Product;

public class ProductImpl implements ProductDao{

	private File file;
	private DataInputStream dataInputStream;
	private DataOutputStream dataOutputStream;
	
		
	public ProductImpl(String fileName) throws IOException {
		super();
		file=FileHelper.createFile(fileName);
		 dataInputStream=new DataInputStream(new FileInputStream(file));
		 dataOutputStream=new DataOutputStream(new FileOutputStream(file));
	}

	@Override
	public boolean addProduct(Product product) throws IOException, FileNotFoundException, ProductCostException {
		// TODO Auto-generated method stub
		boolean status=false;
		dataOutputStream.writeLong(product.getProductId());
		dataOutputStream.writeChars(product.getName());
		if(product.getCost()<0)
			throw new ProductCostException("Product Cost should be above 0");
		else
		    dataOutputStream.writeInt(product.getCost());
		dataOutputStream.writeChars(product.getDop().toString());
		dataOutputStream.writeBoolean(product.isStatus());
		dataOutputStream.close();
		status=true;
		return status;
	}

	@Override
	public Product getProduct() throws IOException {
		// TODO Auto-generated method stub
		Product product=new Product();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		product.setProductId(dataInputStream.readLong());
		//product.setName(dataInputStream.readLine());
		product.setCost(dataInputStream.readInt());			
		//product.setDop(LocalDate.parse(dataInputStream.readLine(), formatter));
		product.setStatus(dataInputStream.readBoolean());
		dataInputStream.close();
		return product;
	}

}
