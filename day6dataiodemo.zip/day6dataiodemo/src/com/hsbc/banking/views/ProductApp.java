package com.hsbc.banking.views;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;

import com.hsbc.banking.bl.ProductBL;
import com.hsbc.banking.bl.ProductBLImpl;
import com.hsbc.banking.exceptions.ProductCostException;
import com.hsbc.banking.models.Product;

public class ProductApp {

	private static ProductBL productBL;
	
	static
	{
		try {
			productBL=new ProductBLImpl("ProductInfo");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Product product=new Product();    
		product.setProductId(5969);
		product.setName("HandSet");
		product.setDop(LocalDate.of(2020, 3, 27));
		product.setCost(2500);
		product.setStatus(true);
		try {
			productBL.addProduct(product);
			System.out.println(productBL.getProduct());
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ProductCostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
