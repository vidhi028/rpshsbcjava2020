package com.hsbc.banking.exceptions;

public class ProductCostException extends Exception {

	public ProductCostException(String message)
	{
		super(message);
	}
}
