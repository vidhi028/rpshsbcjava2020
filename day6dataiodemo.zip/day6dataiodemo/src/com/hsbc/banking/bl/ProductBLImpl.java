package com.hsbc.banking.bl;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.hsbc.banking.dao.ProductDao;
import com.hsbc.banking.dao.ProductImpl;
import com.hsbc.banking.exceptions.ProductCostException;
import com.hsbc.banking.models.Product;

public class ProductBLImpl implements ProductBL {

	private ProductDao productDao;
	
	public ProductBLImpl(String fileName) throws IOException
	{
		productDao=new ProductImpl(fileName);
	}
	
	@Override
	public boolean addProduct(Product product) throws IOException, FileNotFoundException, ProductCostException {
		// TODO Auto-generated method stub
		return productDao.addProduct(product);
	}

	@Override
	public Product getProduct() throws IOException {
		// TODO Auto-generated method stub
		return productDao.getProduct();
	}

}
