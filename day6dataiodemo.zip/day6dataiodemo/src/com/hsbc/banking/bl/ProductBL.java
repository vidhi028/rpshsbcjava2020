package com.hsbc.banking.bl;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.hsbc.banking.exceptions.ProductCostException;
import com.hsbc.banking.models.Product;

public interface ProductBL {

	boolean addProduct(Product product)throws IOException,
	FileNotFoundException,ProductCostException;
	Product getProduct() throws IOException;

}
