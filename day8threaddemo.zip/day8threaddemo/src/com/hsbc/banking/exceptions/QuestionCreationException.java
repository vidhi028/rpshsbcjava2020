package com.hsbc.banking.exceptions;

public class QuestionCreationException extends Exception{

	public QuestionCreationException(String message)
	{
		super(message);
	}
}
