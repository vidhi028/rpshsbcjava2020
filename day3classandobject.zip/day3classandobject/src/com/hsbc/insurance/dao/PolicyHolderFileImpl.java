package com.hsbc.insurance.dao;

import com.hsbc.insurance.models.PolicyHolder;

public class PolicyHolderFileImpl implements PolicyHolderDao{

	@Override
	public boolean addPolicyHolder(PolicyHolder policyHolder) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public PolicyHolder[] getAllPolicyHolders() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PolicyHolder getPolicyHolderById(long policyNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updatePolicyHolder(PolicyHolder policyHolder) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deletePolicyHolder(long policyNo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public PolicyHolder[] getAllSortedPolicyHolders() {
		// TODO Auto-generated method stub
		return null;
	}

}
