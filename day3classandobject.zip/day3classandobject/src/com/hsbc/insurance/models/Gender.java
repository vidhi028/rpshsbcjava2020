package com.hsbc.insurance.models;

public enum Gender {
MALE,FEMALE,TRANSGENDER
}

