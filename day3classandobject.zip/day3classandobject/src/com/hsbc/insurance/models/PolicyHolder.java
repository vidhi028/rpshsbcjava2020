package com.hsbc.insurance.models;

import java.time.LocalDate;
import java.util.Arrays;

//Claim Process needs Policy holder information
public class PolicyHolder {
	private long policyNo;
	private LocalDate fromDate;
	private LocalDate toDate;
	private String nameOfInsured;
	private Gender gender;
	private Address[] addressList;
	private LocalDate dob;
	private long phoneNo;
	private String email;
	
	public long getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(long policyNo) {
		this.policyNo = policyNo;
	}
	public LocalDate getFromDate() {
		return fromDate;
	}
	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}
	public LocalDate getToDate() {
		return toDate;
	}
	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}
	public String getNameOfInsured() {
		return nameOfInsured;
	}
	public void setNameOfInsured(String nameOfInsured) {
		this.nameOfInsured = nameOfInsured;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public Address[] getAddressList() {
		return addressList;
	}
	public void setAddressList(Address[] addressList) {
		this.addressList = addressList;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "PolicyHolder [policyNo=" + policyNo + ", fromDate=" + fromDate + ", toDate=" + toDate
				+ ", nameOfInsured=" + nameOfInsured + ", gender=" + gender + ", addressList="
				+ Arrays.toString(addressList) + ", dob=" + dob + ", phoneNo=" + phoneNo + ", email=" + email + "]";
	}
	
	
	
	

}
