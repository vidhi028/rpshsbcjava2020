//Vidhi Mansharamani

package com.hsbc.ecommerce.models;

import java.io.Serializable;

public class Category implements Serializable{
	
	private String retailProduct;

	public String getRetailProduct() {
		return retailProduct;
	}

	public void setRetailProduct1(String retailProduct) {
		this.retailProduct = retailProduct;
	}

	@Override
	public String toString() {
		return "Category [retailProduct=" + retailProduct + "]";
	}

	public void setRetailProduct(String product) {
		// TODO Auto-generated method stub
		
	}
	
	




}
