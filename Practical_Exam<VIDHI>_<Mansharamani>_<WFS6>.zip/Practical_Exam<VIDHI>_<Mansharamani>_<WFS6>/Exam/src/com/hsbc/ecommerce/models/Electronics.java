//Vidhi Mansharamani


package com.hsbc.ecommerce.models;

import java.io.Serializable;

public class Electronics extends Category implements Serializable{
	
	private int itemCode;
	private String itemName;
	private int quantity;
	private int warranty;
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getWarranty() {
		return warranty;
	}
	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}
	@Override
	public String toString() {
		return "Electronics [itemCode=" + itemCode + ", itemName=" + itemName + ", quantity=" + quantity + ", warranty="
				+ warranty + "]";
	}
	
	

}
