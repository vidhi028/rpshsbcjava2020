//Vidhi Mansharamani

package com.hsbc.ecommerce.models;

import java.io.Serializable;

public class Apparel extends Category implements Serializable{
	
	private int itemCode;
	private String itemName;
	private int quantity;
	private String size;
	private String material;
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	
	
	@Override
	public String toString() {
		return "Apparel [itemCode=" + itemCode + ", itemName=" + itemName + ", quantity=" + quantity + ", size=" + size
				+ ", material=" + material + "]";
	}
	
	
	


}
