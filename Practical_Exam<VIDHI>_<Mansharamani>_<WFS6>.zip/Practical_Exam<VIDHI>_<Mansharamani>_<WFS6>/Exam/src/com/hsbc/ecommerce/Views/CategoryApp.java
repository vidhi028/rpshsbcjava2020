package com.hsbc.ecommerce.Views;

import java.util.ArrayList;
import java.util.Scanner;

import com.hsbc.ecommerce.BL.CategoryBL;
import com.hsbc.ecommerce.models.Category;


public class CategoryApp {
	
	private static CategoryBL categoryBL;	

	
	private static void addCategory()
	{
		Scanner sc= new Scanner(System.in);
		String product;
		ArrayList<Category> categoryList=new ArrayList<Category>();
		categoryList.ensureCapacity(3);
		Category category=null;		
		for(int i=0;i<3;i++)
		{
			System.out.println("Enter Product Category");
			product=sc.nextLine();
			category=new Category();
			category.setRetailProduct(product);
		}
		
	
		
		
	}

}
