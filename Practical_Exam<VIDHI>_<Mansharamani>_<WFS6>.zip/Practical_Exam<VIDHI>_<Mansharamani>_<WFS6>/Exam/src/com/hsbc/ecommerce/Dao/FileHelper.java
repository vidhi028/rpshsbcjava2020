package com.hsbc.ecommerce.Dao;

import java.io.File;
import java.io.IOException;
import java.util.ResourceBundle;

public class FileHelper {
	
	private static File file;
	private static ResourceBundle resourceBundle;
	public static File createFile() throws IOException
	{
		resourceBundle=ResourceBundle.getBundle("com/hsbc/banking/"
				+ "resources/ecommerce");	
		
		file=new File(resourceBundle.getString("fileName"));
		if(!file.exists())
			file.createNewFile();
		
		
        return file; 	
		
		
	}

}
