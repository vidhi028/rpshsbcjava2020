//Vidhi Mansharamani
// Implements DAO Layer

package com.hsbc.ecommerce.Dao;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.hsbc.ecommerce.models.Category;





public class CategoryDaoImpl implements CategoryDao {
	
	private File file;
	private FileOutputStream fileOutputStream;
	private FileInputStream fileInputStream;
	private ObjectOutputStream objectOutputStream;
	private ObjectInputStream objectInputStream;
	
	
	public CategoryDaoImpl() throws IOException
	{
		file=FileHelper.createFile();
	}

	@Override
	public boolean addCategory(List<Category> categoryList) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		
		fileOutputStream=new FileOutputStream(file,true);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		for(Category category : categoryList)
		{
			objectOutputStream.writeObject(category);
		}
		objectOutputStream.close();
		fileOutputStream.close();
		
		return true;
	}

	@Override
	public List<Category> getAllCategories() throws FileNotFoundException, IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
		fileInputStream=new FileInputStream(file);
		objectInputStream=new ObjectInputStream(fileInputStream);
		List<Category> categoryList=new ArrayList<Category>();
		Category category=null;		
		try
		{
			
			while((category=(Category) objectInputStream.readObject())!=null)
				categoryList.add(category);			
					
		}
		catch(EOFException exception)
		{
			
		}
		finally
		{
		objectInputStream.close();
		fileInputStream.close();
		}
		
		return categoryList;
	}

	@Override
	public boolean Apparel(List<com.hsbc.ecommerce.models.Apparel> apparelList)
			throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<com.hsbc.ecommerce.models.Apparel> getAllApparelCategories()
			throws FileNotFoundException, IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean FoodItems(List<com.hsbc.ecommerce.models.FoodItems> foodItemsList)
			throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<com.hsbc.ecommerce.models.FoodItems> getAllFoodItemsCategories()
			throws FileNotFoundException, IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean Electronics(List<com.hsbc.ecommerce.models.Apparel> electronicsList)
			throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<com.hsbc.ecommerce.models.Electronics> getAllElectronicsCategories()
			throws FileNotFoundException, IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}
}

	