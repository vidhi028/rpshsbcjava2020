//Vidhi Mansharamani
//Category DAO Interface


package com.hsbc.ecommerce.Dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.hsbc.ecommerce.models.Apparel;
import com.hsbc.ecommerce.models.Category;
import com.hsbc.ecommerce.models.Electronics;
import com.hsbc.ecommerce.models.FoodItems;

public interface CategoryDao {
	
	boolean addCategory(List<Category> categoryList) throws FileNotFoundException, IOException;
	List<Category> getAllCategories() throws FileNotFoundException, IOException, ClassNotFoundException;
	
	boolean Apparel(List<Apparel> apparelList) throws FileNotFoundException, IOException;
	List<Apparel> getAllApparelCategories() throws FileNotFoundException, IOException, ClassNotFoundException;
	
	boolean FoodItems(List<FoodItems> foodItemsList) throws FileNotFoundException, IOException;
	List<FoodItems> getAllFoodItemsCategories() throws FileNotFoundException, IOException, ClassNotFoundException;
	
	boolean Electronics(List<Apparel> electronicsList) throws FileNotFoundException, IOException;
	List<Electronics> getAllElectronicsCategories() throws FileNotFoundException, IOException, ClassNotFoundException;
	
}
