

package com.hsbc.ecommerce.BL;



import java.io.IOException;
import java.util.List;

import com.hsbc.ecommerce.Dao.CategoryDao;
import com.hsbc.ecommerce.Dao.CategoryDaoImpl;
import com.hsbc.ecommerce.Exceptions.FileCreationException;
import com.hsbc.ecommerce.models.Category;

public class CategoryBLImpl implements CategoryBL{
	
private CategoryDao categoryDao;
	
	public  CategoryBLImpl() throws FileCreationException
	{
		try {
			categoryDao=new CategoryDaoImpl();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//rethrow
				throw new FileCreationException("Not able to create the "
						+ "file, change the location, Check Permission");				
			}		
	}

	@Override
	public boolean addVehicle(List<Category> vehicleList) {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public List<Category> getAllCategories() {
		// TODO Auto-generated method stub
		return null;
	}

}
