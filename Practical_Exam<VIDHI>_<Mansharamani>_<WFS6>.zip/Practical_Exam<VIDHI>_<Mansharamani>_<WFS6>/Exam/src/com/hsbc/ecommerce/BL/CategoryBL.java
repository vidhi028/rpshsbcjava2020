package com.hsbc.ecommerce.BL;

import java.util.List;

import com.hsbc.ecommerce.models.Category;




public interface CategoryBL {
	
	boolean addVehicle(List<Category> categoryList);
	List<Category> getAllCategories(); 
}
	
	
