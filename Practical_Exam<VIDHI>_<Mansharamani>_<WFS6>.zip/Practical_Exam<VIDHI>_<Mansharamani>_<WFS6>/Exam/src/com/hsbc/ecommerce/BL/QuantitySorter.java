package com.hsbc.ecommerce.BL;

import java.util.Comparator;

public class QuantitySorter implements Comparator<Quantity>{
	
	public int compare(Quantity o1, Quantity o2)
	{
		return o1.getDor().compareTo(o2.getDor());
	}

}
