package com.hsbc.banking.dao;

import java.util.regex.Pattern;

import com.hsbc.banking.exceptions.AgeException;
import com.hsbc.banking.exceptions.UserNameException;
import com.hsbc.banking.models.User;

public class UserImpl implements UserDao{

	@Override
	public boolean addUser(User user) {
		// TODO Auto-generated method stub
	    boolean status=false;
	    try
	    {
		if(!Pattern.matches("[a-zA-z]*", user.getUserName()))
			throw new UserNameException("Name should contain only alphabets");
		
		
	    }
	    catch(UserNameException exception)
	    {
	    	System.out.println(exception.getMessage());
	    }
	    try
		{
		if(user.getAge()<0)
			throw new AgeException("Age Value should be between 0 to 99"); 
		}
		catch(AgeException exception)
		{
			System.out.println(exception.getMessage());
		}
	   return status;
	}

	@Override
	public User[] getAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}

}
