package com.hsbc.banking.bl;

import com.hsbc.banking.dao.UserDao;
import com.hsbc.banking.dao.UserImpl;
import com.hsbc.banking.models.User;

public class UserBLImpl implements UserBL {

	private UserDao userDao;
	
	public UserBLImpl()
	{
		userDao=new UserImpl();
	}
		
	@Override
	public boolean addUser(User user) {
		// TODO Auto-generated method stub
		return this.userDao.addUser(user);
	}

	@Override
	public User[] getAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}

}
