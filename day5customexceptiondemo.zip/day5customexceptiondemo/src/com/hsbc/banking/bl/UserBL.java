package com.hsbc.banking.bl;

import com.hsbc.banking.models.User;

public interface UserBL {
	boolean addUser(User user);
	User[] getAllUsers();
}
