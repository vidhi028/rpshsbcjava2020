package com.hsbc.banking.exceptions;

//If username has numbers throw UserName Exception

public class UserNameException extends RuntimeException{

	public UserNameException(String message)
	{
		super(message);
	}
	
}
