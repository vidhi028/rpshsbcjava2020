package com.hsbc.banking.exceptions;

//checked exception
public class AgeException extends Exception{
	
	public AgeException(String message)
	{
		super(message);
	}

}
