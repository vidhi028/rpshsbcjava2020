package com.hsbc.banking.exceptions;

//if age is negative throw age exception
public class AgeException extends RuntimeException{
	
	public AgeException(String message)
	{
		super(message);
	}

}
