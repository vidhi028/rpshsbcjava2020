package com.hsbc.banking.views;

import java.util.Scanner;

import com.hsbc.banking.bl.UserBL;
import com.hsbc.banking.bl.UserBLImpl;
import com.hsbc.banking.models.User;

//User App is view layer calls BL Layer
public class UserApp {
   //connect to business layer
	private static UserBL userBL;
	
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		User user=new User();
		userBL=new UserBLImpl();
		try
		{
		System.out.println("Enter User Name");
		user.setUserName(scanner.nextLine());
		System.out.println("Enter Age");
		user.setAge(scanner.nextByte());
		scanner.nextLine();		
		userBL.addUser(user);
		}
		catch(NullPointerException exception)
		{
			
		}
		finally
		{
			scanner.close();
		}
		
	}
	
}
