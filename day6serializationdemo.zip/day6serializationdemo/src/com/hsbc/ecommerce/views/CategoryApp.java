package com.hsbc.ecommerce.views;

import java.io.IOException;

import com.hsbc.ecommerce.bl.CategoryBL;
import com.hsbc.ecommerce.bl.CategoryBLImpl;
import com.hsbc.ecommerce.exceptions.FileCreateException;
import com.hsbc.ecommerce.models.Category;

public class CategoryApp {

	private static CategoryBL categoryBl;
	//capture custom exception
	static
	{
		try {
			categoryBl=new CategoryBLImpl("Category.txt");
		} catch (FileCreateException e) {
			
			System.out.println(e.getMessage());
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Store the object
		Category category =new Category();
		category.setCategoryId(439864);
		category.setName("Garments");
		try {
			categoryBl.addCategory(category);
			System.out.println(categoryBl.getAllCategories());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
