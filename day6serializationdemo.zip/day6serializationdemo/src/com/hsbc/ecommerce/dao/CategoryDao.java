package com.hsbc.ecommerce.dao;

import java.io.IOException;

import com.hsbc.ecommerce.models.Category;

public interface CategoryDao {
	
	boolean addCategory(Category category) throws IOException;
	Category[] getAllCategories() throws ClassNotFoundException, IOException;

}
