package com.hsbc.ecommerce.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.hsbc.ecommerce.models.Category;

public class CategoryImpl implements CategoryDao{

	private File file;
	private FileOutputStream fileOutputStream;
	private FileInputStream fileInputStream;
	private ObjectOutputStream objectOutputStream;
	private ObjectInputStream objectInputStream;
	
	public CategoryImpl(String fileName) throws IOException
	{
		file=FileHelper.createFile(fileName);
		fileOutputStream=new FileOutputStream(file);
		fileInputStream=new FileInputStream(file);
		objectOutputStream=new ObjectOutputStream(fileOutputStream);
		objectInputStream=new ObjectInputStream(fileInputStream);
	}
	
	
	@Override
	public boolean addCategory(Category category) throws IOException {
		// TODO Auto-generated method stub
		boolean status=false;
		objectOutputStream.writeObject(category);
		objectOutputStream.close();
		fileOutputStream.close();
		status=true;
		return status;
	}

	@Override
	public Category getAllCategories() throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		Category category= (Category) objectInputStream.readObject();		
		objectInputStream.close();
		fileInputStream.close();
		return category;
	}

}
