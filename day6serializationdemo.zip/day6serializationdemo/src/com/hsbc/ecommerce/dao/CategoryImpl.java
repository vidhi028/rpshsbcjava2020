package com.hsbc.ecommerce.dao;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;

import com.hsbc.ecommerce.models.Category;

public class CategoryImpl implements CategoryDao{

	private File file;
	private FileOutputStream fileOutputStream;
	private FileInputStream fileInputStream;
	private ObjectOutputStream objectOutputStream;
	private ObjectInputStream objectInputStream;	
	public CategoryImpl(String fileName) throws IOException
	{
		file=FileHelper.createFile(fileName);
		fileOutputStream=new FileOutputStream(file,true);//append mode		
		objectOutputStream=new ObjectOutputStream(fileOutputStream);	
	}
		
	@Override
	public boolean addCategory(Category category) throws IOException {
		// TODO Auto-generated method stub
		boolean status=false;
			
		objectOutputStream.writeObject(category);
		
		status=true;
		return status;
	}
	
	public int getObjectCount() throws IOException, ClassNotFoundException
	{
		fileInputStream=new FileInputStream(file);	
		objectInputStream=new ObjectInputStream(fileInputStream);
		Category category=null;
		int count=0;
		try
		{
		while(objectInputStream.readObject()!=null)
		{
			count++;
		}
		}
		catch(EOFException exception)
		{
			
		}
		catch(StreamCorruptedException exception)
		{
			System.out.println(exception.getMessage());
		}
		finally
		{
		objectInputStream.close();
		fileInputStream.close();
		}
		return count;
	}
	

	@Override
	public Category[] getAllCategories() throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		fileInputStream=new FileInputStream(file);//append mode		
		objectInputStream=new ObjectInputStream(fileInputStream);
		//int count=getObjectCount();
		Category[] categories=new Category[75];	
		
		int pos = 0;
		Category category = null;
		try {
			while ((category = (Category) objectInputStream.readObject()) != null) {
				categories[pos] = category;
				pos++;
				if(pos>74)
					break;
			}
		} catch (EOFException exception) {

		} 
		catch(StreamCorruptedException exception)
		{
			System.out.println(exception.getMessage());
		}
		
		finally {
			objectInputStream.close();
			fileInputStream.close();
		}
		 
		return categories;
	}

}
