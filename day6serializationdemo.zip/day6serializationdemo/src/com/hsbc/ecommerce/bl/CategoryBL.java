package com.hsbc.ecommerce.bl;

import java.io.IOException;

import com.hsbc.ecommerce.models.Category;

public interface CategoryBL {
	boolean addCategory(Category category) throws IOException;
	Category[] getAllCategories() throws ClassNotFoundException, IOException;
}
