package com.hsbc.banking.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCopyImpl implements FileCopyDao{

	private File readFile,writeFile;
	private FileInputStream fileInputStream;
	private FileOutputStream fileOutputStream;
	private byte[] fileContent;
	public FileCopyImpl(String readFileName,String writeFileName) throws FileNotFoundException
	{
		readFile=new File(readFileName);
		writeFile=new File(writeFileName);		
		fileInputStream=new FileInputStream(readFile);
		fileOutputStream=new FileOutputStream(writeFile);		
		
	}
	
	@Override
	public boolean copyFileContent() throws IOException {
		// TODO Auto-generated method stub
		fileContent=new byte[(int) readFile.length()];
		fileInputStream.read(fileContent);
		String data=new String(fileContent);
		fileOutputStream.write(fileContent);
        System.out.println(data);
        fileOutputStream.close();
        fileInputStream.close();
		return true;
	}

}
