package com.hsbc.banking.bl;

import java.io.IOException;

public interface FileCopyBL {
	boolean copyFileContent() throws IOException;
}
