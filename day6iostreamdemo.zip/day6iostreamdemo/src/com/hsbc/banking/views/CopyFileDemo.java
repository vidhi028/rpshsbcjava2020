package com.hsbc.banking.views;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.hsbc.banking.bl.FileCopyBL;
import com.hsbc.banking.bl.FileCopyBLImpl;

public class CopyFileDemo {

	private static FileCopyBL fileCopyBL;
	
	static
	{
		try {
			fileCopyBL=new FileCopyBLImpl("Employee.txt","EmployeeClone.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        try {
        	System.out.print("File Copy Status.....");
			System.out.println(fileCopyBL.copyFileContent());
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}

}
