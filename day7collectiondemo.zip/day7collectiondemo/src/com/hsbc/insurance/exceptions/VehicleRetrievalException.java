package com.hsbc.insurance.exceptions;

public class VehicleRetrievalException extends Exception {

	public VehicleRetrievalException(String message)
	{
		super(message);
	}
}
