package com.hsbc.banking.dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;

import com.hsbc.banking.exceptions.DOBException;
import com.hsbc.banking.models.Customer;

public class CustomerFileImpl implements CustomerDao{

	private File file;
	private FileWriter fileWriter;
	private BufferedWriter bufferedWriter;
	public CustomerFileImpl(String dirPath, String fileName) throws IOException
	{
		file=FileHelper.createFile(dirPath, fileName);
		fileWriter=new FileWriter(file);
		
	}
	
	
	@Override
	public boolean addCustomer(Customer customer) throws DOBException, IOException {
		// TODO Auto-generated method stub
		boolean status=true;
		
		if(customer.getDob().isAfter(LocalDate.now()))
		{
		    status=false;
			throw new DOBException("DOB cannot be greater than today...");
		
		}
		else
		{
			bufferedWriter=new BufferedWriter(fileWriter);
			bufferedWriter.write(String.valueOf(customer.getCustomerId()));
			bufferedWriter.append(",");
			bufferedWriter.write(customer.getName());
			bufferedWriter.append(",");
			bufferedWriter.write(customer.getDob().toString());
			bufferedWriter.newLine();
			bufferedWriter.close();
			
			status=true;
		}
		
		
		
		return status;
	}

}
