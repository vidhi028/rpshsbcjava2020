package com.hsbc.banking.exceptions;

public class DOBException extends Exception{
	
	public DOBException(String message)
	{
		
	}

}
